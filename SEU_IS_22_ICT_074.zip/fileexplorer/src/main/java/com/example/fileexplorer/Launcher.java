package com.example.fileexplorer;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(FileExplorer.class, args);
    }
}

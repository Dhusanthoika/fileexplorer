package com.example.fileexplorer;

import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

import java.awt.Desktop;
import java.io.File;
import java.util.Arrays;
import java.util.Comparator;

public class FileExplorerController {

    @FXML private TreeView<File> treeView;
    @FXML private ListView<File> listView;
    @FXML private Label fileInfoLabel;
    @FXML private MenuItem openFolderMenu;
    @FXML private MenuItem exitMenu;

    private Stage stage;

    public void setStage(Stage stage) { this.stage = stage; }

    @FXML
    public void initialize() {

        // Root node
        TreeItem<File> root = new TreeItem<>(new File("Computer"));
        root.setExpanded(true);

        // Add system drive roots
        for (File r : File.listRoots()) {
            root.getChildren().add(createNode(r));
        }

        treeView.setRoot(root);
        treeView.setShowRoot(true);

        // When a folder is selected → show files on right side
        treeView.getSelectionModel().selectedItemProperty().addListener((obs, oldV, newV) -> {
            if (newV != null) {
                File folder = newV.getValue();

                if (folder.isDirectory()) {
                    File[] items = folder.listFiles();
                    if (items != null)
                        Arrays.sort(items, Comparator.comparing(File::getName));
                    listView.getItems().setAll(items != null ? items : new File[0]);
                }
            }
        });

        // On file click
        listView.setOnMouseClicked(e -> {
            File f = listView.getSelectionModel().getSelectedItem();
            if (f == null) return;

            fileInfoLabel.setText(
                    "Name: " + f.getName() +
                            " | Type: " + (f.isDirectory() ? "Folder" : "File") +
                            " | Size: " + (f.isFile() ? (f.length() / 1024) + " KB" : "-")
            );

            // Double-click to open file
            if (e.getClickCount() == 2 && f.isFile()) {
                try {
                    Desktop.getDesktop().open(f);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        // Menu: Open folder
        openFolderMenu.setOnAction(e -> {
            DirectoryChooser chooser = new DirectoryChooser();
            chooser.setTitle("Select Folder");
            File folder = chooser.showDialog(stage);

            if (folder != null) {
                TreeItem<File> node = createNode(folder);
                treeView.getRoot().getChildren().add(node);
                treeView.getSelectionModel().select(node);
            }
        });

        // Menu: Exit
        exitMenu.setOnAction(e -> System.exit(0));
    }

    // Lazy-loaded TreeItem
    private TreeItem<File> createNode(File file) {
        return new TreeItem<>(file) {
            private boolean firstTimeChildren = true;

            @Override
            public ObservableList<TreeItem<File>> getChildren() {
                if (firstTimeChildren) {
                    firstTimeChildren = false;
                    super.getChildren().setAll(buildChildren(this));
                }
                return super.getChildren();
            }

            @Override
            public boolean isLeaf() {
                return file.isFile();

            }
        };
    }

    // Load folder children
    private ObservableList<TreeItem<File>> buildChildren(TreeItem<File> item) {
        File f = item.getValue();
        if (f != null && f.isDirectory()) {
            File[] files = f.listFiles(File::isDirectory);
            if (files != null) {
                ObservableList<TreeItem<File>> children = FXCollections.observableArrayList();
                for (File child : files) {
                    children.add(createNode(child));
                }
                return children;
            }
        }
        return FXCollections.emptyObservableList();
    }
}
